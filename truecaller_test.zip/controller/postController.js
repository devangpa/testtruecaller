const axios = require('axios')

const requestdUrl = "https://public-api.wordpress.com/rest/v1.1/sites/107403796/posts/?number=25"
exports.getrecentpost = async (req, res, next) => {
    try {

        let fetchedData = await axios.get(requestdUrl)
        console.log(fetchedData.data.posts.length)
        res.status(200).json({
            data: fetchedData.data
        })


    } catch (e) {
        res.status(200).json({
            error: e
        })

    }

}