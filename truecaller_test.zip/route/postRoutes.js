const express = require('express');
const router = express.Router();

const postcontroller = require('./../controller/postController')

router.get('/posts', postcontroller.getrecentpost)

module.exports = router;