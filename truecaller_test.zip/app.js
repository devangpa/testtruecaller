const express = require('express')
const morgan = require('morgan');
const cors = require('cors');
// const bodyParser = require('body-parser');
const postRoutes = require('./route/postRoutes')

//start server
const app = express()

app.enable('trust proxy');
app.use(morgan('dev'));
app.use(cors())

app.use('/api/v1', postRoutes)



const PORT = 2000
app.listen(PORT, () => {
    console.log(`You Are Listen ${PORT}`)
})