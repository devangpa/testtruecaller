const axios = require('axios')
const moment = require('moment')
var _ = require('underscore');


export class filterbyCatagories {
    constructor(dataArray) {
        this.data = dataArray;

    }

    //fitered catagory
    filterBycatagory(catagory) {
        let findaindex = []
        let sortedCatagoryArray = []

        let filterArray = this.data.map((el) => {
            let data = Object.keys(el.categories).includes(catagory)
            return data
        })
        filterArray.forEach((el, index) => {
            if (el === true) {
                sortedCatagoryArray.push(this.data[index])
            }
        })
        return sortedCatagoryArray
    }

    //get catagory

    getcatagories() {
        let fullarray = [];
        let filterdecatagories

        this.data.forEach(el => {
            fullarray.push(Object.keys(el.categories))
        })

        filterdecatagories = _.reduceRight(fullarray, function (a, b) { return a.concat(b); }, [])
        let retunrArray = _.uniq(filterdecatagories)
        return retunrArray
    }
    //Catagory Count
    catagorycounthandler(catagory) {
        let findaindex = []
        let sortedCatagoryArray = []

        let filterArray = this.data.map((el) => {
            let data = Object.keys(el.categories).includes(catagory)
            return data
        })
        filterArray.forEach((el, index) => {
            if (el === true) {
                sortedCatagoryArray.push(this.data[index])
            }
        })
        let count = sortedCatagoryArray.length
        return count
    }

    getcattagorycount() {
        let catagory = this.getcatagories()
        let catagoryCount = []
        catagory.forEach((el) => {
            catagoryCount.push({ Catagory: el, Count: this.catagorycounthandler(el) })
        })
        return catagoryCount
    }

}