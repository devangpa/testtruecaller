import React from 'react'
// import logo from './logo.svg';
// import './App.css';
import axios from 'axios'

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      post: []
    }



  }

  componentDidMount = async () => {
    let getpost = await axios.get('http://localhost:2000/api/v1/posts')

    this.setState({ post: getpost.data.data.posts })
    console.log(this.state.post)


  }
  render() {
    return (
      <div className="App">
        <hr />
        {
          this.state.post.map((el) => {
            return (
              <div class="container" >
                <div class="card text-center" style={{ border: "1px solid black" }}>
                  <div class="card-header">
                    {el.title}
                  </div>
                  <div class="card-body">

                    {el.excerpt}
                    <a href="#" class="btn btn-primary">Go somewhere</a>
                  </div>

                  <div class="card-footer text-muted">
                    2 days ago
                  </div>
                </div>
                <hr />
              </div>
            )

          })
        }

      </div>)
  }
}



export default App;
